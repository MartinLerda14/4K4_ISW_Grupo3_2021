export default {
  dark: "#03041d",
  grey: "#cdccd2",
  light: "#f2f2f4",
  orange: "#fb6e3b",
  circle_grey: "#f5f5f5",
  white: "#ffffff",
  transparent: 'transparent'
};
